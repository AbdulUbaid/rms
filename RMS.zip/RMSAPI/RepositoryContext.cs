﻿
using RMSAPI.Models;
using Microsoft.EntityFrameworkCore;
namespace RMSAPI
{
    public class RepositoryContext : DbContext
    {
        public RepositoryContext(DbContextOptions options)
            : base(options)
    {

    }
        public DbSet<Request> Requests { get; set; }
        public DbSet<Region> Regions { get; set; }
        public DbSet<Audit_Log> audit_Logs { get; set; }
        public DbSet<UserRole> userRoles { get; set; }
        public DbSet<City> cities { get; set; }
        public DbSet<Item> items { get; set; }
        public DbSet<SubItem> SubItems { get; set; }
        public DbSet<Company> companies { get; set; }
        public DbSet<Unit> units { get; set; } 
        public DbSet<Status> statuses { get; set; }
       
    }

}
