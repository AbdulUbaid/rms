﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RMSAPI.Models
{
    public class User
    {
        public string Name { get; set; }
        public string NameAr { get; set; }
        public string Username { get; set; }
        public string Company { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string NationalId { get; set; }
    }
}
