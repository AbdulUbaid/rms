﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RMSAPI.Models
{
    public class ErrorViewModel
    {
        public bool IsErrorFound { get { return true; } }//this will always return true as this is in error object.
        public int StatusCode { get; internal set; }

        public string ExceptionPath { get; set; }
        public string ExceptionMessage { get; set; }
        public string StackTrace { get; set; }

        public string RequestId { get; set; }
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
