﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RMSAPI.Models
{
    public class Item
    {
        public Item()
        {
            SubItems = new HashSet<SubItem>();
        }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ItemId { get; set; }
        [Required(ErrorMessage = "Item is required")]
        [StringLength(100)]
        public string Description { get; set; }
        [Required]
        public float TotalPrice { get; set; }
        [Required]
        public int CompanyId { get; set; }
        [Required]
        public int RequestId { get; set; }
        public bool IsDelete { get; set; }

        public virtual Company Company { get; set; }
        public virtual Request Request { get; set; }
        public virtual ICollection<SubItem> SubItems { get; set; }

    }
}
