﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RMSAPI.Models
{
    public class RequestView
    {
        public int ReqId { get; set; }
        public int ReqCode { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int CityId { get; set; }
        public string Attachment { get; set; }
        public string Location { get; set; }
        public int Status { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
        public string CityName { get; set; }
       // public string ItemName { get; set; }
    }
}
