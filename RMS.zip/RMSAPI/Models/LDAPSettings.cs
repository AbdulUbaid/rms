﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RMSAPI.Models
{
    public class LDAPSettings
    {
        public string ADPath { get; set; }
        public string SuperUser { get; set; }
        public string SuperPass { get; set; }
        public string DomainName { get; set; }

        public string RDN_OU { get; set; }
        public string RDN_DC1 { get; set; }
        public string RDN_DC2 { get; set; }
    }
}
