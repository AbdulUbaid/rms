﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RMSAPI.Models
{
    public class Request
    {
        public Request()
        {
            Items = new HashSet<Item>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ReqId { get; set; }

        public int ReqCode { get; set; }
        [Required(ErrorMessage = "Title is required")]
        [StringLength(100)]
        public string Title { get; set; }
        [Required(ErrorMessage = "Description is required")]
        [StringLength(200)]
        public string Description { get; set; }
        [Required]
        public int CityId { get; set; }
        [Required]
        public string  Attachment { get; set; }
        [Required]
        public string  Location { get; set; }
        [Required(ErrorMessage = "Status is required")]
        public int Status { get; set; }
        [Required]
        public int CreatedBy { get; set; }
        [Required]
        public DateTime CreatedOn { get; set; }
        [Required]
        public int UpdatedBy { get; set; }
        [Required]
        public DateTime UpdatedOn { get; set; }
        public bool IsDelete { get; set; }
     
        public virtual City City { get; set; }
        public virtual ICollection<Item> Items { get; set; }          
    }  

    }
