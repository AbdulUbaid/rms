﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RMSAPI.Models
{
    public class SubItem
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Description { get; set; }
        [Required]
        public int ItemId { get; set; }
        [Required]
        public int UnitId { get; set; }
        [Required]
        public int Quantity { get; set; }
        [Required]
        public  float Price { get; set; }
        public bool IsDelete { get; set; }

        public virtual Item Item { get; set; }
        public virtual Unit Unit { get; set; }
    }
}
