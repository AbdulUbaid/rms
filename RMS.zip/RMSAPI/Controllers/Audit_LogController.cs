﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RMSAPI;
using RMSAPI.Models;

namespace RMSAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Audit_LogController : ControllerBase
    {
        private readonly RepositoryContext _context;

        public Audit_LogController(RepositoryContext context)
        {
            _context = context;
        }

        // GET: api/Audit_Log
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Audit_Log>>> Getaudit_Logs()
        {
            return await _context.audit_Logs.ToListAsync();
        }

        // GET: api/Audit_Log/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Audit_Log>> GetAudit_Log(int id)
        {
            var audit_Log = await _context.audit_Logs.FindAsync(id);

            if (audit_Log == null)
            {
                return NotFound();
            }

            return audit_Log;
        }

        // PUT: api/Audit_Log/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAudit_Log(int id, Audit_Log audit_Log)
        {
            if (id != audit_Log.Id)
            {
                return BadRequest();
            }

            _context.Entry(audit_Log).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Audit_LogExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Audit_Log
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Audit_Log>> PostAudit_Log(Audit_Log audit_Log)
        {
            _context.audit_Logs.Add(audit_Log);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAudit_Log", new { id = audit_Log.Id }, audit_Log);
        }

        // DELETE: api/Audit_Log/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Audit_Log>> DeleteAudit_Log(int id)
        {
            var audit_Log = await _context.audit_Logs.FindAsync(id);
            if (audit_Log == null)
            {
                return NotFound();
            }

            _context.audit_Logs.Remove(audit_Log);
            await _context.SaveChangesAsync();

            return audit_Log;
        }

        private bool Audit_LogExists(int id)
        {
            return _context.audit_Logs.Any(e => e.Id == id);
        }
    }
}
