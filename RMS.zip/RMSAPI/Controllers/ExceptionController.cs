﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RMSAPI.Models;

namespace RMSAPI.Controllers
{
    ////[Route("api/[controller]")]
    //[ApiController]
    public class ExceptionController : Controller
    {
        private readonly ILogger<ExceptionController> _logger;

        // Inject ASP.NET Core ILogger service. Specify the Controller
        // Type as the generic parameter. This helps us identify later
        // which class or controller has logged the exception
        public ExceptionController(ILogger<ExceptionController> logger)
        {
            this._logger = logger;
        }
        [Route("Exception/Error")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public JsonResult Error()
        {
            // Retrieve the exception Details
            var exceptionHandlerPathFeature =
                    HttpContext.Features.Get<IExceptionHandlerPathFeature>();

            ErrorViewModel errorViewModel = new ErrorViewModel()
            {
                StatusCode = -1,
                ExceptionPath = exceptionHandlerPathFeature.Path,
                ExceptionMessage = exceptionHandlerPathFeature.Error.Message,
                StackTrace = exceptionHandlerPathFeature.Error.StackTrace,
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier

            };

            // LogError() method logs the exception under Error category in the log
            _logger.LogError($"The path {exceptionHandlerPathFeature.Path} " + $"threw an exception {exceptionHandlerPathFeature.Error}");


            return Json(errorViewModel);
        }

        [Route("Exception/ErrorResourceNotFound/{statusCode}")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public JsonResult ErrorResourceNotFound(int statusCode)
        {
            var statusCodeResult = HttpContext.Features.Get<IStatusCodeReExecuteFeature>();
            string message = $"{statusCode} error occured. Path = " +
                        $"{statusCodeResult.OriginalPath} and QueryString = " +
                        $"{statusCodeResult.OriginalQueryString}";

            ErrorViewModel errorViewModel = new ErrorViewModel()
            {
                StatusCode = statusCode,
                ExceptionPath = message,
                ExceptionMessage = "NotFound",
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            };

            // LogWarning() method logs the message under
            // Warning category in the log
            _logger.LogWarning(message);

            return Json(errorViewModel);
           
        }
    }
}