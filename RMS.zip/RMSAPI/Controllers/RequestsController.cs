﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RMSAPI;
using RMSAPI.Models;


namespace RMSAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestsController : ControllerBase
    {
        private readonly RepositoryContext _context;

        public RequestsController(RepositoryContext context)
        {
            _context = context;
        }

        // GET: api/Requests/5
        [HttpGet("GetRequests/{id}")]
        public async Task<ActionResult<Request>> GetRequests(int id)
        {
            var requests = await _context.Requests.Include(x => x.Items).Include("Items.SubItems").FirstOrDefaultAsync(y => y.ReqId == id);
            if (requests == null)
            {
                return NotFound();
            }
            return requests;
        }

        // GET: api/Requests
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Request>>> GetRequests()
        {
            return await _context.Requests.ToListAsync();
        }

        // GET: api/Requests/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Request>> GetRequest(int id)
        {
            var request = await _context.Requests.FindAsync(id);

            if (request == null)
            {
                return NotFound();
            }

            return request;
        }

        // PUT: api/Requests/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRequest(int id, Request request)
        {
            using (var dbTransaction = _context.Database.BeginTransaction())
            {
                if (id != request.ReqId)
                {
                    return BadRequest();
                }
                try
                {                    
                    Item item = new Item();
                    SubItem subitem = new SubItem();
                    // Status status = new Status();

                    var lst = request.Items;
                    var sub = lst.FirstOrDefault().SubItems;

                    var subitems = request.Items.FirstOrDefault();
                    var actionResult = Approval();                  

                    if (1==1)
                    {
                        
                    item.TotalPrice = request.Items.FirstOrDefault().TotalPrice;
                    item.Description = request.Items.FirstOrDefault().Description;
                    item.CompanyId = request.Items.FirstOrDefault().CompanyId;
                    item.RequestId = request.Items.FirstOrDefault().RequestId;
                        item.ItemId= request.Items.FirstOrDefault().ItemId;

                        subitem.Description = sub.FirstOrDefault().Description;
                        subitem.Price = sub.FirstOrDefault().Price;
                        subitem.ItemId = sub.FirstOrDefault().ItemId;
                        subitem.Quantity = sub.FirstOrDefault().Quantity;
                        subitem.Id = sub.FirstOrDefault().Id;
                        subitem.UnitId = sub.FirstOrDefault().UnitId;
                       

                        _context.Entry(request).State = EntityState.Modified;
                    _context.Entry(item).State = EntityState.Modified;
                    _context.Entry(subitem).State = EntityState.Modified;
                  //  _context.Entry(subitem).State = EntityState.Modified;
                    //_context.items.Add(item);
                    //_context.SubItems.Add(subitem);
                    //_context.SaveChanges();
                    // _context.Entry(item).State = EntityState.Modified;
                    //_context.items = EntityState.Modified;
                    await _context.SaveChangesAsync();
                    dbTransaction.Commit();


                    }                  
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RequestExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        dbTransaction.Rollback();
                        throw;
                    }
                }
            }

            return NoContent();
        }

        // POST: api/Requests
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Request>> PostRequest(Request request)
        {

            int iItemCount = request.Items.Count;

            if (iItemCount == 0)
            {
                return BadRequest();
            }
            else
            {
                foreach (var item in request.Items)
                {
                    int nSubitemCount = item.SubItems.Count;
                    if (nSubitemCount == 0)
                    {
                        return BadRequest();
                    }
                }
            }
            using (var dbTransaction = _context.Database.BeginTransaction())
            {
                try
                {
                    Request req = new Request()
                    {

                        ReqCode = request.ReqCode,
                        Title = request.Title,
                        Description = request.Description,
                        CityId = request.CityId,
                        Attachment = request.Attachment,
                        Location = request.Location,
                        Status = request.Status,
                        CreatedBy = request.CreatedBy,
                        CreatedOn = request.CreatedOn,
                        UpdatedBy = request.UpdatedBy,
                        UpdatedOn = request.UpdatedOn,
                        IsDelete = request.IsDelete
                    };

                    var lst = request.Items;
                    var test = lst.FirstOrDefault().SubItems;
                    var itemslst = request.Items.FirstOrDefault();
                    var subitemlst = itemslst.SubItems.FirstOrDefault();

                    _context.Requests.Add(req);
                    _context.items.Add(itemslst);
                    _context.SubItems.Add(subitemlst);

                    await _context.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }
            //    _context.Requests.Add(request);
            //await _context.SaveChangesAsync();
            return CreatedAtAction("GetRequest", new { id = request.ReqId }, request);
        }

        // DELETE: api/Requests/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Request>> DeleteRequest(int id)
        {
            var request = await _context.Requests.FindAsync(id);
            if (request == null)
            {
                return NotFound();
            }

            using (var dbTransaction = _context.Database.BeginTransaction())
            {
                try
                {
                    var objItem = await _context.items.FindAsync(request.ReqId);
                    _context.items.Remove(objItem);

                    var objsubItem = await _context.SubItems.FindAsync(request.ReqId);
                    _context.SubItems.Remove(objsubItem);

                    _context.Requests.Remove(request);
                    await _context.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }
            return request;
        }

        private bool RequestExists(int id)
        {
            return _context.Requests.Any(e => e.ReqId == id);
        }

        public ActionResult Approval()
            {

            var Check = _context.statuses.FirstOrDefault().IsDelete;
            if(Check==1)
            {
                return RedirectToAction("PutRequest");
            }
            else
            {
                return BadRequest();
            }
               
            }

        public ActionResult  Denied (Request request)
        {
            var newcheck = _context.statuses.FirstOrDefault().IsDelete;
            if(newcheck==0)
            {
                return NoContent();
            }
            else
            {
                return BadRequest();
            }
        }

    }
}
