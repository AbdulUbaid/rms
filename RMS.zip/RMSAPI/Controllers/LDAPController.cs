﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using RMSAPI.Models;
using System;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;

namespace RMSAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LDAPController : ControllerBase
    {
        private readonly IOptions<LDAPSettings> _ldapSettings;
        private readonly string ADPath;
        private readonly string SuperUser;
        private readonly string SuperPass;
        private readonly string DomainName;
        private readonly string RDN_OU, RDN_DC1, RDN_DC2;

        public LDAPController(IOptions<LDAPSettings> ldapSettings)
        {
            _ldapSettings = ldapSettings;

            ADPath = _ldapSettings.Value.ADPath;
            SuperUser = _ldapSettings.Value.SuperUser;
            SuperPass = _ldapSettings.Value.SuperPass;
            DomainName = _ldapSettings.Value.DomainName;
            RDN_OU = _ldapSettings.Value.RDN_OU;
            RDN_DC1 = _ldapSettings.Value.RDN_DC1;
            RDN_DC2 = _ldapSettings.Value.RDN_DC2;

        }
        DirectoryEntry GetDirectoryObject(string ADUsername, string ADPassword)
        {
            try
            {

                var oDE = new DirectoryEntry(ADPath, ADUsername, ADPassword, AuthenticationTypes.Secure);

                return oDE;
            }
            catch
            {

            }

            return null;
        }

        DirectoryEntry GetUser(DirectoryEntry de, string userName)
        {
            DirectorySearcher deSearch = new DirectorySearcher();
            deSearch.SearchRoot = de;

            deSearch.Filter = "(&(objectClass=user)(SAMAccountName=" + userName + "))";
            deSearch.SearchScope = SearchScope.Subtree;

            SearchResult results = deSearch.FindOne();

            if (!(results == null))
            {
                return new DirectoryEntry(results.Path, SuperUser, SuperPass, AuthenticationTypes.Secure);
            }
            else
            {
                return null;
            }

        }

        [HttpGet("GetUser/{username}")]
        public IActionResult GetUser(string username)

        {
            using (
                PrincipalContext pc = new PrincipalContext(ContextType.Domain, DomainName, SuperUser, SuperPass))
            {
                UserPrincipal User = UserPrincipal.FindByIdentity(pc, IdentityType.SamAccountName, username);
                if (User == null) { return Ok(new User()); }

                using (DirectoryEntry de = User.GetUnderlyingObject() as DirectoryEntry)
                {
                    var AdUser = new User()
                    {
                        Username = username,
                        Name = User.Name,
                        NameAr = User.DisplayName,
                        Company = de.Properties.Contains("company") ? de.Properties["company"].Value.ToString() : "",
                        Email = User.EmailAddress,  
                        Mobile = de.Properties.Contains("mobile") ? de.Properties["mobile"].Value.ToString() : "",
                        NationalId = de.Properties.Contains("employeeNumber") ? de.Properties["employeeNumber"].Value.ToString() : ""
                    };

                    //foreach (var Group in User.GetGroups())
                    //{
                    //    if (Group.Name == "Domain Users" || Group.Name == "Administrators" || Group.Name == "RDP USers" || Group.Name == "Domain Computers") continue;

                    //    AdUser.Groups.Add(Group.Name);
                    //}
                    ////Ubaid
                    return Ok(AdUser);
                }
            }
        }
        [HttpGet("ValidateUserCredentials/{UserName,Password}")]
        public bool ValidateUserCredentials(string userName, string password)
        {

            try
            {
                using (var pc = new PrincipalContext(ContextType.Domain, _ldapSettings.Value.DomainName))
                {
                    return pc.ValidateCredentials(userName, password);
                }
            }
            catch (Exception)
            {
                //throw ex;
                return false;
            }

        }
    }
}
